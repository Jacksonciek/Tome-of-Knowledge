Kelompok Ascent IF231-D

Nama Anggota Kelompok :
1. Hans Philemon Limanza (00000070710) (hans.philemon@student.umn.ac.id)
2. Jackson Lawrence (00000070612) (jackson.lawrence@student.umn.ac.id)
3. Malvin Paskalis (00000070394) (malvin.paskalis@student.umn.ac.id)
4. Willsen Fiderick (00000070412) (willsen.fiderick@student.umn.ac.id)


Link Github : https://github.com/Achxter/PTI-D_Lec_Game

Penjelasan dan ketentuan tentang GAME UMNGOTCHA oleh Ascent :

1. Game yang disediakan oleh Ascent memiliki konsep seperti game tamagotchi pada umumnya.
2. Tampilan dari game tersebut merupakan tampilan dengan design yang dibuat oleh kelompok Ascent.
3. Pada game ini pemain dapat menginputkan nama sebagai username untuk bermain game tersebut.
4. Selain itu, pemain dapat memilih hewan peliharaan anjing atau kucing sesuai dengan selera masing-masing. 
5. Pada game ini pemain menggunakan beberapa status bar (Status bar health, play, eat, dan sleep) untuk memvisualisasikan kondisi dari hewan peliharaan yang pemain pakai sebagai karakter in-game. 
6. Untuk mempertahankan nilai status bar, pemain dapat memberi makan, mengajak bermain, mengobati, dan beristirahat dengan karakter yang dipilih oleh pemain pada awalnya.
7. Perlu diketahui bahwa usahakan jangan sampai status bar health menjadi habis dan karakter yang pemain pilih akan mati.
8. Akan tetapi, game yang kelompok kami buat memiliki konsep jika karakter tersebut pertama kali ditampilkan atau mati, maka yang terjadi selanjutnya adalah pemain akan diberikan nyawa dan semua status bar sebanyak 50% dari total status bar.
9. Saat pengguna memilih mode "main", pengguna akan diajak untuk mengerakkan karakter menuju bola menggunakan tanda panah pada keyboard atau layar yang sudah disediakan dalam rentang waktu 30 detik. 
10. Selain itu, karakter kucing dan anjing dapat berevolusi sebanyak 2 tahap ketika sudah melewati batas waktu tertentu.
11. Waktu disesuaikan dengan game yang telah disediakan pada tampilan game tersebut.
12. Background yang berganti-gantin disesuaikan dengan waktu yang ada pada game seperti yang sudah dijelaskan sebelumnya, dan bertransformasi dari kondisi pagi, siang, sore, hingga malam.
13. Game akan selesai jika pemain telah berhasil mengumpulkan bola yang terdapat pada game dan status bar game pun bertambah.

Enjoy & Happy Playing !!!!