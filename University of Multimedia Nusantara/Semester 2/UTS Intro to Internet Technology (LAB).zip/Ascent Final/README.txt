Kelompok Ascent IF231-DL

Nama Anggota Kelompok :
1. Hans Philemon Limanza (00000070710) (hans.philemon@student.umn.ac.id)
2. Jackson Lawrence (00000070612) (jackson.lawrence@student.umn.ac.id)
3. Malvin Paskalis (00000070394) (malvin.paskalis@student.umn.ac.id)
4. Willsen Fiderick (00000070412) (willsen.fiderick@student.umn.ac.id)

Link Github : https://github.com/Achxter/PTI-D_Lab_Game

Penjelasan dan ketentuan tentang GAME IDLE CLICKER oleh Ascent :

1. Game yang di buat oleh Ascent kali ini memiliki konsep game seperti tahu bulat dengan judul "Idle Clicker".
2. Tampilan dari game tersebut Ascent buat dengan tema city night, sehingga tampilan dari designnya yang menarik daripada game auto cliker pada umumnya.
3. Pada tampilan awal yaitu halaman HOME terdapat 2 pilihan yaitu "Game" dan "About Us", serta efek parallax dengan memindahkan kursor mouse.
4. Pemain dapat mendengarkan lagu sambil bermain game "Idle Clicker" dengan musik yang telah diberikan pada game tersebut.
5. Pemain juga dapat melihat halaman "About Us" yang terdiri dari 4 anggota Ascent yang telah membuat program game ini secara bersama-sama.
6. Dalam halaman "Game", pemain dapat menekan karakter "Skeleton" untuk menghasilkan uang / income gold sebanyak mungkin dengan tujuan untuk meningkatkan "Shop Level" dan "Income Gold".
7. Pemain dapat membeli auto clicker sebanyak 1 kali dengan tujuan untuk menambahkan passive income gold.
8. Pemain dapat meningkatkan Income Gold pada menu Upgrade Income.
9. Di dalam upgrade income terdapat 3 jenis pilihan barang untuk meningkatkan income gold yaitu Gems, Scroll, dan Potion, dengan deskripsi yang sudah tercantum pada menu tersebut.
10. Jika pemain telah berhasil membeli untuk mengupgrade "Shop Level" yang terdapat pada menu "Upgrade Shop", maka cost dari "Upgrade Shop" akan meningkat.
11. Konsep dari poin nomor 10 berlaku sama persis dengan membeli 3 jenis pilihan barang untuk meningkatkan income gold yaitu Gems, Scroll, dan Potion yang terdapat pada menu "Upgrade Income".
12. Jika pemain berhasil untuk membeli 3 jenis pilihan barang, maka income gold akan bertambah sesuai dengan menu yang tercantum.
13. Pertambahan income gold akan sesuai dengan tampilan yang terdapat persis di atas karakter "Skeleton".

Enjoy Players & Happy Playing!!!

Copyright © 2023 Ascent All rights reserved.